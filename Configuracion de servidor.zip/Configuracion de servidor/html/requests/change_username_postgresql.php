<?php
// Conexión a la base de datos
$host = "localhost";
$port = "5432";
$dbname = "usuarios_db";
$user = "donckeydrive";
$password = "donckeydrive1";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Conexión fallida: " . pg_last_error());
}

// Obtener datos del formulario
$email = $_POST['email'];
$nuevo_nombre = $_POST['nombrenuevo'];

// Validar que los campos no estén vacíos
if (empty($email) || empty($nuevo_nombre)) {
    die("El email y el nuevo nombre son obligatorios.");
}

// Consultar la base de datos para obtener el usuario
$sql = "SELECT * FROM usuarios_table WHERE email = $1";
$stmt = pg_prepare($conn, "get_user", $sql);
$result = pg_execute($conn, "get_user", array($email));

if ($result) {
    $row = pg_fetch_assoc($result);
    $usuario_id = $row['id'];

    // Actualizar el nombre de usuario en la base de datos
    $update_sql = "UPDATE usuarios_table SET nombre = $1 WHERE id = $2";
    $update_stmt = pg_prepare($conn, "update_username", $update_sql);
    $result_update = pg_execute($conn, "update_username", array($nuevo_nombre, $usuario_id));

    if ($result_update) {
        echo "Nombre de usuario actualizado correctamente.";
    } else {
        echo "Error al actualizar el nombre de usuario.";
    }
} else {
    echo "Usuario no encontrado.";
}

pg_close($conn);
?>
