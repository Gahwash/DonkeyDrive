<?php
// Función para obtener el espacio de almacenamiento disponible en la Raspberry Pi
function obtenerEspacioDisponible() {
    // Ejecutar el comando 'df' para obtener información del disco
    $output = shell_exec('df -h /');
    
    // Dividir la salida en líneas
    $lines = explode("\n", trim($output));
    
    // Obtener la segunda línea (que contiene la información del sistema de archivos raíz)
    $data = preg_split('/\s+/', $lines[1]);
    
    // Retornar la columna que contiene el espacio disponible
    return $data[3]; // Columna de espacio disponible en formato legible
}

// Llamar a la función y almacenar el resultado
$espacioDisponible = obtenerEspacioDisponible();

// Mostrar el espacio disponible
echo "Espacio disponible en la Raspberry Pi: " . $espacioDisponible;
?>
