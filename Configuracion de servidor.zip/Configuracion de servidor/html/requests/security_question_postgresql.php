<?php
// Datos de conexión a la base de datos PostgreSQL
$host = 'localhost';
$port = '5432';
$dbname = 'usuarios_db';
$user = 'donckeydrive';
$password = 'donckeydrive1';

// Obtener los parámetros del POST
$email = $_POST['email'];
$pregunta = $_POST['pregunta'];
$respuesta = $_POST['respuesta'];

// Conexión a la base de datos
$dbconn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$dbconn) {
    die("Error: No se pudo conectar a la base de datos.");
}

// Realizar la consulta en la tabla securityquestion
$query = "SELECT * FROM usuarios_table WHERE email = '$email' AND (pregunta1 = '$pregunta' OR pregunta2 = '$pregunta') AND (respuesta1 = '$respuesta' OR respuesta2 = '$respuesta')";
$result = pg_query($dbconn, $query);

if (!$result) {
    die("Error en la consulta: " . pg_last_error());
}

// Verificar si hay alguna coincidencia
if (pg_num_rows($result) > 0) {
    echo "true"; // Si hay coincidencia, devolver true
} else {
    echo "false"; // Si no hay coincidencia, devolver false
}

// Cerrar la conexión a la base de datos
pg_close($dbconn);
?>
