<?php

// Obtener el número de pin desde la solicitud
$pin_number = $_GET['pin'];

// Especificar la ruta relativa al script de Python (considerando la estructura de carpetas proporcionada)
$python_script_path = "../domotica/generator_control.py";

// Ejecutar el script de Python para controlar el LED con el número de pin proporcionado
$output = shell_exec("python3 $python_script_path $pin_number");

// Mostrar el resultado (opcional)
echo "<pre>$output</pre>";

?>
