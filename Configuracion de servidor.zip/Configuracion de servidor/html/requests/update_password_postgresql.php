<?php
// Datos de conexión a la base de datos PostgreSQL
$host = 'localhost';
$port = '5432';
$dbname = 'usuarios_db';
$user = 'donckeydrive';
$password = 'donckeydrive1';

// Obtener el correo electrónico y la nueva contraseña del formulario
$email = $_POST['email'] ?? '';
$new_password = $_POST['new_password'] ?? '';

// Verificar si el correo electrónico y la nueva contraseña no están vacíos
if (empty($email) || empty($new_password)) {
    echo "Error: Correo electrónico o contraseña no proporcionados.";
    exit;
}

// Conexión a la base de datos
$dbconn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$dbconn) {
    die("Error: No se pudo conectar a la base de datos.");
}

// Consulta SQL para actualizar la contraseña del usuario
$query = "UPDATE usuarios_table SET contraseña = '$new_password' WHERE email = '$email'";

$result = pg_query($dbconn, $query);

if ($result) {
    echo "La contraseña se actualizó correctamente para el usuario con correo electrónico $email.";
} else {
    echo "Error al actualizar la contraseña: " . pg_last_error();
}

// Cerrar la conexión a la base de datos
pg_close($dbconn);
?>
