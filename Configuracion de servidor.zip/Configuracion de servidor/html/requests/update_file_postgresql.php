<?php
$host = "localhost";
$port = "5432";
$dbname = "usuarios_db";
$user = "donckeydrive";
$password = "donckeydrive1";

// Conectar a PostgreSQL
$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    echo json_encode(array("error" => "Error: No se pudo conectar a la base de datos."));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file'])) {
    $file = $_FILES['file'];
    $fileName = $file['name'];
    $fileTmpPath = $file['tmp_name'];

    // Mover el archivo a una carpeta de destino
    $uploadDir = 'uploads/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    $dest_path = $uploadDir . $fileName;

    if (move_uploaded_file($fileTmpPath, $dest_path)) {
        // Guardar la información del archivo en la base de datos
        $query = "INSERT INTO files_table (name, path) VALUES ($1, $2)";
        $result = pg_query_params($conn, $query, array($fileName, $dest_path));

        if ($result) {
            echo json_encode(array("message" => "Archivo subido y registrado exitosamente."));
        } else {
            echo json_encode(array("error" => "Error al registrar la información del archivo en la base de datos."));
        }
    } else {
        echo json_encode(array("error" => "Error al mover el archivo a la carpeta de destino."));
    }
} else {
    echo json_encode(array("error" => "No se recibió ningún archivo."));
}

// Cerrar la conexión
pg_close($conn);
?>
