<?php

// Datos de conexión a la base de datos
$host = "localhost";
$port = "5432";
$dbname = "usuarios_db";
$user = "donckeydrive";
$password = "donckeydrive1";

// Conexión a la base de datos
try {
    $dsn = "pgsql:host=$host;port=$port;dbname=$dbname;user=$user;password=$password";
    $pdo = new PDO($dsn);
} catch (PDOException $e) {
    die("Error al conectarse a la base de datos: " . $e->getMessage());
}

// Función para obtener solo el nombre del archivo sin la ruta completa
function getFileName($filePath) {
    return basename($filePath);
}

// Función para obtener las rutas de archivos basadas en el correo electrónico
function obtenerRutasArchivos($pdo, $email) {
    try {
        // Consulta SQL para obtener file_path basado en el correo electrónico
        $query = "SELECT file_path FROM archivos_table WHERE email = :email";
        $statement = $pdo->prepare($query);
        $statement->bindParam(":email", $email);
        $statement->execute();

        // Obtener las rutas de archivos
        $rutas = $statement->fetchAll(PDO::FETCH_ASSOC);
        
        return $rutas;
    } catch (PDOException $e) {
        die("Error al obtener las rutas de archivos: " . $e->getMessage());
    }
}

// Procesar el formulario si se ha enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener el correo electrónico del formulario
    $emailUsuario = $_POST["email"];

    // Obtener rutas de archivos basadas en el correo electrónico
    $rutas = obtenerRutasArchivos($pdo, $emailUsuario);

    // Mostrar las rutas de archivos encontradas o un mensaje si no se encuentra ninguna ruta para ese correo electrónico
    if ($rutas) {
        foreach ($rutas as $ruta) {
            $fileName = getFileName($ruta["file_path"]); // Obtener solo el nombre del archivo sin la ruta completa
            echo "$fileName\n"; // Agregar un salto de línea después de cada nombre de archivo
        }
    } else {
        echo "No se encontraron rutas de archivos asociadas a este correo electrónico.";
    }
}
?>
