  GNU nano 7.2                               download_pictures_postgresql.php                                         
<?php
header('Content-Type: application/json');

// Verificar si se han proporcionado los argumentos necesarios
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['email']) && isset($_GET['name_file'])) {
    // Obtener los datos del formulario
    $email = $_GET['email'];
    $name_file = $_GET['name_file'];

    // Directorio donde se almacenan los archivos
    $upload_dir = "/var/www/html/users/$email/documentos/";

    // Ruta completa del archivo
    $file_path = $upload_dir . $name_file;

    // Verificar si el archivo existe
    if (file_exists($file_path)) {
        // Limpiar el búfer de salida y deshabilitar la salida de compresión
        if (ob_get_level()) {
            ob_end_clean();
        }

        // Configurar cabeceras para la descarga del archivo
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file_path));

        // Asegurar que no hay contenido en el buffer de salida
        flush();

        // Leer el archivo y enviar su contenido al navegador
        readfile($file_path);

        exit;
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Archivo no encontrado']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Faltan datos requeridos']);
}
?>
