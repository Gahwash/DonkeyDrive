<?php
// Conexión a la base de datos
$host = "localhost";
$port = "5432";
$dbname = "usuarios_db";
$user = "donckeydrive";
$password = "donckeydrive1";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Conexión fallida: " . pg_last_error());
}

// Obtener datos del formulario
$email = $_POST['email'];
$current_password = $_POST['contraseña'];
$new_password = $_POST['nuevacontraseña'];

// Validar que los campos no estén vacíos
if (empty($email) || empty($current_password) || empty($new_password)) {
    die("Todos los campos son obligatorios.");
}

// Consultar la base de datos para obtener la contraseña actual
$sql = "SELECT contraseña FROM usuarios_table WHERE email = $1";
$stmt = pg_prepare($conn, "get_password", $sql);
$result = pg_execute($conn, "get_password", array($email));

if ($result) {
    $row = pg_fetch_assoc($result);
    $stored_password = $row['contraseña'];

    // Verificar que la contraseña actual sea correcta
    if ($current_password === $stored_password) {
        // Actualizar la contraseña en la base de datos
        $update_sql = "UPDATE usuarios_table SET contraseña = $1 WHERE email = $2";
        $update_stmt = pg_prepare($conn, "update_password", $update_sql);
        $result_update = pg_execute($conn, "update_password", array($new_password, $email));

        if ($result_update) {
            echo "Contraseña actualizada correctamente.";
        } else {
            echo "Error al actualizar la contraseña.";
        }
    } else {
        echo "La contraseña actual no es correcta.";
    }
} else {
    echo "Usuario no encontrado.";
}

pg_close($conn);
?>
