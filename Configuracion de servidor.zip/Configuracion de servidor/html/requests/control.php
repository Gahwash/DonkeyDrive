<?php

function toggleLED($pin, $state) {
    // Comando para ejecutar el script Python como root
    $command = "python3 /var/www/html/domotica/control.py {$pin} {$state}";

    // Ejecutar el comando y obtener la salida
    exec($command, $output, $returnCode);

    // Verificar el código de retorno
    if ($returnCode === 0) {
        return implode("\n", $output);
    } else {
        return "Error: No se pudo cambiar el estado del pin {$pin}.";
    }
}

// Obtener el número de pin y el estado desde la solicitud POST
$pinNumber = $_POST['pin'] ?? '';
$state = $_POST['state'] ?? '';

if ($pinNumber !== '' && $state !== '') {
    $result = toggleLED($pinNumber, $state);
    echo $result;
} else {
    echo "Error: No se proporcionó un número de pin o estado.";
}
?>
