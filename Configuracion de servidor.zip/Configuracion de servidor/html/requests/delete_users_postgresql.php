<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Establecer los parámetros de conexión
    $host = "localhost";
    $port = "5432";
    $dbname = "usuarios_db";
    $user = "donckeydrive";
    $password = "donckeydrive1";

    // Establecer la conexión con PostgreSQL
    $conexion = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

    // Verificar la conexión
    if (!$conexion) {
        echo "Error al conectar con la base de datos.";
        exit;
    }

    // Obtener los datos del formulario
    $email = $_POST["email"];
    $contraseña = $_POST["contraseña"];

    // Preparar la consulta SQL utilizando sentencias preparadas para prevenir inyección SQL
    $query = "SELECT * FROM usuarios_table WHERE email = $1 AND contraseña = $2";

    // Ejecutar la consulta preparada
    $resultado = pg_query_params($conexion, $query, array($email, $contraseña));

    // Verificar si se encontró un usuario con el nombre de usuario y contraseña proporcionados
    if ($resultado && pg_num_rows($resultado) > 0) {
        echo "Usuario encontrado"; // Enviar respuesta de éxito al cliente

        // Ejecutar el script de Node.js para eliminar los datos del usuario
        $command = "node /var/www/html/processes/utils/delete_user_all.js \"$email\"";
        exec($command, $output, $retval);

        // Verificar si hubo errores al ejecutar el script de Node.js
        if ($retval !== 0) {
            echo "Error al ejecutar el script de Node.js: " . implode("\n", $output);
        } else {
            echo "Datos del usuario eliminados correctamente.";

            // Preparar y ejecutar las consultas para eliminar los datos del usuario de las tablas relacionadas
            $query_usuarios = "DELETE FROM usuarios_table WHERE email = $1";
            $query_files = "DELETE FROM files_table WHERE email=$1";
            $query_archivos = "DELETE FROM archivos_table WHERE email=$1"; 

            pg_query_params($conexion, $query_usuarios, array($email));
            pg_query_params($conexion, $query_files, array($email));
            pg_query_params($conexion, $query_archivos, array($email));
        }
    } else {
        echo "Correo electrónico o contraseña incorrectos"; // Enviar mensaje de error al cliente
    }

    // Liberar el resultado
    pg_free_result($resultado);

    // Cerrar la conexión
    pg_close($conexion);
}
?>
