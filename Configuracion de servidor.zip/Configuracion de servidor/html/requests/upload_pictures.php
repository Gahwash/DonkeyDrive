<?php
header('Content-Type: application/json');

// Verificar si se han proporcionado los argumentos necesarios
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email']) && isset($_FILES['file'])) {
    // Obtener los datos del formulario
    $email = $_POST['email'];
    $file = $_FILES['file'];

    // Directorio donde se almacenarán los archivos
    $upload_dir = "/var/www/html/users/$email/imagenes/";

    // Verificar si no hay errores en la ejecución de la acción
    $archivoEntrada = $upload_dir . basename($file['name']);

    // Verificar y crear el directorio de destino si no existe
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    // Mover el archivo subido al directorio de destino
    if (move_uploaded_file($file['tmp_name'], $archivoEntrada)) {
        // Guardar la información del archivo en la base de datos
        try {
            // Configuración de la base de datos
            $host = 'localhost';
            $db = 'usuarios_db';
            $user = 'donckeydrive';
            $password = 'donckeydrive1';

            // Conectar a la base de datos
            $pdo = new PDO("pgsql:host=$host;dbname=$db", $user, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Insertar información en la tabla pictures_table
            $stmt = $pdo->prepare('INSERT INTO pictures_table (email, file_path) VALUES (:email, :file_path)');
            $stmt->execute([
                ':email' => $email,
                ':file_path' => $archivoEntrada // Guardar el nombre del archivo en la base de datos
            ]);

            echo json_encode(['status' => 'success', 'message' => 'Archivo guardado en la base de datos exitosamente']);
        } catch (PDOException $e) {
            echo json_encode(['status' => 'error', 'message' => 'Error al guardar en la base de datos: ' . $e->getMessage()]);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error al mover el archivo subido']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Faltan datos requeridos']);
}
?>
