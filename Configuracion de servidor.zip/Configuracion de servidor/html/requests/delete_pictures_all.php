<?php
header('Content-Type: application/json');

// Verificar si se han proporcionado los argumentos necesarios
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email']) && isset($_POST['file_name'])) {
    // Obtener los datos del formulario
    $email = $_POST['email'];
    $file_name = $_POST['file_name']; // Nombre del archivo cifrado

    // Construir la ruta completa del archivo cifrado
    $file_path = "/var/www/html/users/$email/imagenes/$file_name";

    // Verificar si el archivo cifrado existe en la tabla
    try {
        // Configuración de la base de datos
        $host = 'localhost';
        $db = 'usuarios_db';
        $user = 'donckeydrive';
        $password = 'donckeydrive1';

        // Conectar a la base de datos
        $pdo = new PDO("pgsql:host=$host;dbname=$db", $user, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Buscar el archivo cifrado en la base de datos
        $stmt = $pdo->prepare('SELECT * FROM pictures_table WHERE email = :email AND file_path = :file_path');
        $stmt->execute([
            ':email' => $email,
            ':file_path' => $file_path
        ]);

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            // Eliminar la fila de la tabla
            $deleteStmt = $pdo->prepare('DELETE FROM pictures_table WHERE email = :email AND file_path = :file_path');
            $deleteStmt->execute([
                ':email' => $email,
                ':file_path' => $file_path
            ]);

            // Eliminar el archivo cifrado
            if (file_exists($file_path)) {
                unlink($file_path);
                echo json_encode(['status' => 'success', 'message' => 'Archivo y registro en la base de datos eliminados correctamente']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'El archivo cifrado no existe']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'El archivo cifrado no fue encontrado en la base de datos']);
        }
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => 'Error al conectar con la base de datos: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Faltan datos requeridos']);
}
?>
