<?php

// Configuración de la conexión a la base de datos
$host = "localhost"; // Cambia esto si tu servidor de base de datos está en otro lugar
$port = "5432"; // Puerto por defecto de PostgreSQL
$dbname = "usuarios_db"; // Cambia esto por el nombre de tu base de datos
$user = "donckeydrive"; // Cambia esto por tu nombre de usuario de PostgreSQL
$password = "donckeydrive1"; // Cambia esto por tu contraseña de PostgreSQL

// Conexión a la base de datos
$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

// Verificar la conexión
if (!$conn) {
    die("Conexión fallida: " . pg_last_error());
}

// Función para obtener el nombre de usuario basado en el email
function getUserNameByEmail($conn, $email) {
    $query = "SELECT nombre FROM usuarios_table WHERE email = $1";
    $result = pg_query_params($conn, $query, array($email));

    if (!$result) {
        return "Error en la consulta";
    }

    $row = pg_fetch_assoc($result);
    if (!$row) {
        return "Usuario no encontrado";
    }

    return $row['nombre'];
}

// Ejemplo de uso
$email = $_GET['email']; // Obtener el correo electrónico del parámetro GET
$username = getUserNameByEmail($conn, $email);
echo "$username";

// Cerrar conexión
pg_close($conn);

?>
