<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Establecer los parámetros de conexión
    $host = "localhost";
    $port = "5432";
    $dbname = "usuarios_db";
    $user = "donckeydrive";
    $password = "donckeydrive1";

    // Establecer la conexión con PostgreSQL
    $conexion = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

    // Verificar la conexión
    if (!$conexion) {
        echo "Error al conectar con la base de datos.";
        exit;
    }

    // Obtener los datos del formulario
    $nombre = $_POST["nombre"];
    $apellidos = $_POST["apellidos"];
    $email = $_POST["email"];
    $contraseña = $_POST["contraseña"];
    $pregunta1 = $_POST["pregunta1"];
    $respuesta1 = $_POST["respuesta1"];
    $pregunta2 = $_POST["pregunta2"];
    $respuesta2 = $_POST["respuesta2"];

    // Preparar la consulta SQL utilizando sentencias preparadas para prevenir inyección SQL
    $query = "INSERT INTO usuarios_table (nombre, apellidos, email, contraseña, pregunta1, respuesta1, pregunta2, respuesta2)
              VALUES ($1, $2, $3, $4, $5, $6, $7, $8)";

    // Ejecutar la consulta preparada
    $resultado = pg_query_params($conexion, $query, array($nombre, $apellidos, $email, $contraseña, $pregunta1, $respuesta1, $pregunta2, $respuesta2));

    // Verificar si la inserción fue exitosa
    if ($resultado) {
        // Ejecutar el script de Node.js para crear la carpeta
        $output = null;
        $retval = null;
        $command = escapeshellcmd("node /var/www/html/processes/utils/createFolders.js $email");
        exec($command, $output, $retval);

        if ($retval == 0) {
            // Obtener la dirección de la carpeta (suponiendo que el script de Node.js devuelve la dirección)
            $direccion = implode("\n", $output);

            // Insertar el email y la dirección en la tabla files_table
            $query_file = "INSERT INTO files_table (email, path) VALUES ($1, $2)";
            $resultado_file = pg_query_params($conexion, $query_file, array($email, $direccion));

            if ($resultado_file) {
                echo "success"; // Enviar respuesta de éxito al cliente
            } else {
                echo "Error al insertar datos en la tabla files_table: " . pg_last_error($conexion);
            }
        } else {
            echo "Error al crear la carpeta: " . implode("\n", $output);
        }
    } else {
        echo "Error al insertar datos en la base de datos: " . pg_last_error($conexion);
    }

    // Cerrar la conexión
    pg_close($conexion);
}
?>
