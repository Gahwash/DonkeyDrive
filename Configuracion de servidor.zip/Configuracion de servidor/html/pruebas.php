<?php
// Conexión a la base de datos
$conexion = pg_connect("host=nombre_del_host dbname=ususarios_db user=donckeydrive password=donckeydrive1");

// Verificar la conexión
if (!$conexion) {
    die("Error en la conexión: " . pg_last_error());
}

// Obtener los datos del formulario
$codigo = $_POST['codigo'];
$nombre = $_POST['nombre'];
$foto = file_get_contents($_FILES['foto']['tmp_name']);

// Preparar la consulta SQL para insertar los datos
$query = "INSERT INTO persona (codigo, nombre, foto) VALUES ($codigo, '$nombre', '$foto')";

// Ejecutar la consulta
$resultado = pg_query($conexion, $query);

// Verificar si la inserción fue exitosa
if ($resultado) {
    echo "Persona insertada correctamente.";
} else {
    echo "Error al insertar la persona: " . pg_last_error($conexion);
}

// Cerrar la conexión
pg_close($conexion);
?>
