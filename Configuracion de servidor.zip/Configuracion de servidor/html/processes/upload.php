<?php
// Configuración de la base de datos PostgreSQL
$host = 'localhost';
$dbname = 'usuarios_db';
$username = 'donckeydrive';
$password = 'donckeydrive1';

try {
    // Conexión a la base de datos PostgreSQL
    $pdo = new PDO("pgsql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Recibir los datos del formulario
    $email = $_POST['email'];
    $username = $_POST['username'];
    $file_name = $_FILES['file']['name'];
    $file_tmp = $_FILES['file']['tmp_name'];

    // Leer el contenido del archivo
    $file_content = file_get_contents($file_tmp);

    // Preparar la consulta SQL para insertar el archivo en la base de datos
    $stmt = $pdo->prepare("INSERT INTO archivos (email, username, file_name, file_content) VALUES (:email, :username, :file_name, :file_content)");

    // Bind parameters
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':file_name', $file_name);
    $stmt->bindParam(':file_content', $file_content, PDO::PARAM_LOB);

    // Ejecutar la consulta
    $stmt->execute();

    // Comprobar si se insertó correctamente
    if ($stmt->rowCount() > 0) {
        echo "Archivo subido exitosamente";
    } else {
        echo "Error al subir el archivo";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
