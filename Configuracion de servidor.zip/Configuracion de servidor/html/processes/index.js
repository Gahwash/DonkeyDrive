const { cifrarYGuardarContrasena } = require('./utils/cifrado');

// Llamada a la función
cifrarYGuardarContrasena('Juan', 'Pérez', 'juan@example.com', 'miContraseñaSegura');
