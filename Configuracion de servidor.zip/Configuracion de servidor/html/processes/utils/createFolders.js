const fs = require('fs');
const path = require('path');

// Función para crear carpetas
function createFolders(email) {
    const rootDir = path.join('/var/www/html/users', email); // Crear carpeta con el nombre del correo
    const documentsDir = path.join(rootDir, 'documentos'); // Crear subcarpeta 'documentos'
    const imagesDir = path.join(rootDir, 'imagenes'); // Crear subcarpeta 'imagenes'

    try {
        // Verificar si la carpeta principal ya existe
        if (!fs.existsSync(rootDir)) {
            fs.mkdirSync(rootDir, { recursive: true });
            console.log(`Carpeta creada: ${rootDir}`);
        } else {
            console.log(`La carpeta ${rootDir} ya existe.`);
        }

        // Verificar si la subcarpeta 'documentos' ya existe
        if (!fs.existsSync(documentsDir)) {
            fs.mkdirSync(documentsDir, { recursive: true });
            console.log(`Subcarpeta creada: ${documentsDir}`);
        } else {
            console.log(`La subcarpeta ${documentsDir} ya existe.`);
        }

        // Verificar si la subcarpeta 'imagenes' ya existe
        if (!fs.existsSync(imagesDir)) {
            fs.mkdirSync(imagesDir, { recursive: true });
            console.log(`Subcarpeta creada: ${imagesDir}`);
        } else {
            console.log(`La subcarpeta ${imagesDir} ya existe.`);
        }
    } catch (error) {
        console.error(`Error al crear las carpetas: ${error.message}`);
        process.exit(1);
    }
}

// Obtener el correo electrónico del usuario
const email = process.argv[2];
if (!email) {
    console.error('Por favor, proporciona una dirección de correo electrónico.');
    process.exit(1);
}

// Llamar a la función para crear carpetas
createFolders(email);
