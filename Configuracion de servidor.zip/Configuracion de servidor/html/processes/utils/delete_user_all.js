const fs = require('fs');
const path = require('path');

// Obtener el correo electrónico del argumento de línea de comandos
const email = process.argv[2];

if (!email) {
    console.error("Por favor, proporciona el correo electrónico como argumento.");
    process.exit(1);
}

const directoryPath = path.join('/var/www/html/users/', email);

// Verificar si el directorio existe
fs.access(directoryPath, fs.constants.F_OK, (err) => {
    if (err) {
        console.error(`El directorio ${directoryPath} no existe.`);
    } else {
        // Borrar el directorio y su contenido
        fs.rm(directoryPath, { recursive: true }, (err) => {
            if (err) {
                console.error(`Error al borrar el directorio ${directoryPath}: ${err}`);
            } else {
                console.log(`Los datos del usuario con email ${email} han sido borrados correctamente.`);
            }
        });
    }
});
