const { Pool } = require('pg');
const bcrypt = require('bcrypt');

// Verificar que se proporcionen suficientes argumentos
if (process.argv.length !== 4) {
    console.error('Por favor, proporcione el correo electrónico y la contraseña como argumentos.');
    process.exit(1);
}

// Obtener el correo electrónico y la contraseña de los argumentos de la línea de comandos
const email = process.argv[2];
const contraseña = process.argv[3];

// Configurar los parámetros de conexión
const pool = new Pool({
    user: 'donckeydrive',
    host: 'localhost',
    database: 'usuarios_db',
    password: 'donckeydrive1',
    port: 5432,
});

// Función para cifrar una contraseña con bcrypt
async function cifrarContraseña(contraseña) {
    const saltRounds = 10; // Número de rondas de cifrado
    const salt = await bcrypt.genSalt(saltRounds);
    const hash = await bcrypt.hash(contraseña, salt);
    return hash;
}

// Ejecutar el script
(async () => {
    try {
        // Cifrar la contraseña dependiendo del correo electrónico
        const contraseñaCifrada = await cifrarContraseña(contraseña);

        // Establecer la conexión con la base de datos
        const client = await pool.connect();

        // Ejecutar la consulta SQL para actualizar la contraseña cifrada en la tabla
        const query = `UPDATE usuarios_table SET contraseña = $1 WHERE email = $2`;
        const values = [contraseñaCifrada, email];
        const result = await client.query(query, values);
        console.log('Contraseña cifrada actualizada correctamente:', result);

        // Liberar el cliente de la piscina de conexiones
        client.release();
    } catch (error) {
        // Manejar errores
        console.error('Error:', error);
    } finally {
        // Cerrar la piscina de conexiones cuando hayamos terminado
        pool.end();
    }
})();
