const crypto = require('crypto');

// Genera una clave aleatoria de 32 bytes (256 bits)
const generarClaveAleatoria = () => {
    return crypto.randomBytes(32).toString('hex');
};

// Ejemplo de uso: genera una clave aleatoria e imprímela en la consola
const claveAleatoria = generarClaveAleatoria();
console.log('Clave aleatoria:', claveAleatoria);
