//node Prueba.js cifrar archivo_original archivo_cifrado clave_secreta
//node Prueba.js descifrar archivo_cifrado archivo_descifrado clave_secreta

const fs = require('fs');
const crypto = require('crypto');

// Función para cifrar un archivo
function cifrarArchivo(archivoEntrada, archivoSalida, clave) {
    const readStream = fs.createReadStream(archivoEntrada);
    const writeStream = fs.createWriteStream(archivoSalida);
    const iv = crypto.randomBytes(16); // Genera un vector de inicialización aleatorio
    const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(clave, 'hex'), iv);

    writeStream.write(iv); // Escribe el vector de inicialización en el archivo

    readStream.pipe(cipher).pipe(writeStream);

    // Eliminar el archivo original después de cifrarlo
    fs.unlink(archivoEntrada, err => {
        if (err) {
            console.error(`Error al eliminar el archivo original: ${err}`);
        } else {
            console.log(`Archivo original ${archivoEntrada} eliminado correctamente`);
        }
    });
}

// Función para descifrar un archivo
function descifrarArchivo(archivoCifrado, archivoDescifrado, clave) {
    const readStream = fs.createReadStream(archivoCifrado);
    const writeStream = fs.createWriteStream(archivoDescifrado);
    let iv;

    readStream.once('readable', () => {
        iv = readStream.read(16); // Lee el vector de inicialización del archivo cifrado
        const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(clave, 'hex'), iv);

        readStream.pipe(decipher).pipe(writeStream);
    });

    // Eliminar el archivo original después de descifrarlo
    fs.unlink(archivoCifrado, err => {
        if (err) {
            console.error(`Error al eliminar el archivo cifrado: ${err}`);
        } else {
            console.log(`Archivo cifrado ${archivoCifrado} eliminado correctamente`);
        }
    });
}

// Obtener argumentos de la línea de comandos
const args = process.argv.slice(2); // Ignorar los dos primeros argumentos (node y nombre del script)
const accion = args[0];
const archivoEntrada = args[1];
const clave = args[2];

// Verificar la cantidad de argumentos
if (accion === 'cifrar' && args.length === 3) {
    const archivoSalida = archivoEntrada + ".cif";
    cifrarArchivo(archivoEntrada, archivoSalida, clave);
    console.log(`Archivo ${archivoEntrada} cifrado y guardado como ${archivoSalida}`);
} else if (accion === 'descifrar' && args.length === 3) {
    const archivoSalida = archivoEntrada.replace('.cif', '');
    descifrarArchivo(archivoEntrada, archivoSalida, clave);
    console.log(`Archivo ${archivoEntrada} descifrado y guardado como ${archivoSalida}`);
} else {
    console.error('Uso: node Prueba.js <accion> <archivo_entrada> <clave>\nAcciones permitidas: cifrar, descifrar');
    process.exit(1);
}
