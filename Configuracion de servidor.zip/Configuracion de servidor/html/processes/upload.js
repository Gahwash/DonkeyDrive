function uploadFile() {
    const email = document.getElementById('email').value;
    const username = document.getElementById('username').value;
    const file = document.getElementById('file').files[0];

    if (!email || !username || !file) {
        alert('Por favor, complete todos los campos y seleccione un archivo');
        return;
    }

    const formData = new FormData();
    formData.append('email', email);
    formData.append('username', username);
    formData.append('file', file);

    fetch('../processes/upload.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (response.ok) {
            alert('Archivo subido correctamente');
        } else {
            alert('Error al subir el archivo');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error al subir el archivo');
    });
}
