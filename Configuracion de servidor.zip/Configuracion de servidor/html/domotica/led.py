import RPi.GPIO as GPIO
import sys

def setup(pin):
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(pin, GPIO.OUT)

def turn_on(pin):
    GPIO.output(pin, GPIO.HIGH)
    print(f"Pin {pin} encendido")

def main(pin):
    try:
        setup(pin)
        turn_on(pin)
        # Mantenemos el programa en un bucle infinito para mantener el pin encendido
        while True:
            pass
    except KeyboardInterrupt:
        print("\nPrograma terminado por el usuario.")
    except Exception as e:
        print("Error:", e)
    finally:
        GPIO.cleanup()

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Uso: python3 control.py numero_de_pin")
        sys.exit(1)
    pin_number = int(sys.argv[1])
    main(pin_number)
