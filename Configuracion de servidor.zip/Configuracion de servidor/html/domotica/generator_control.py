import sys

# Obtener el número de pin desde los argumentos de la línea de comandos
pin_number = sys.argv[1]

# Generar el contenido del script Python para controlar el LED en el pin especificado
led_script_content = f"""
import RPi.GPIO as GPIO
import time

# Configurar el modo de la GPIO
GPIO.setmode(GPIO.BCM)

# Número de pin de la GPIO que controla el LED
led_pin = {pin_number}

# Configurar el pin del LED como salida
GPIO.setup(led_pin, GPIO.OUT)

try:
    while True:
        # Encender el LED
        GPIO.output(led_pin, GPIO.HIGH)
        print(f"LED en el pin {led_pin} encendido")
        
        # Esperar 1 segundo
        time.sleep(1)
        
        # Apagar el LED
        GPIO.output(led_pin, GPIO.LOW)
        print(f"LED en el pin {led_pin} apagado")
        
        # Esperar 1 segundo
        time.sleep(1)

except KeyboardInterrupt:
    # En caso de interrupción del teclado, limpiar y salir
    GPIO.cleanup()
"""

# Escribir el contenido en un nuevo archivo Python
with open(f"led_control_{pin_number}.py", "w") as file:
    file.write(led_script_content)

print(f"Script de control para el pin {pin_number} generado exitosamente")
