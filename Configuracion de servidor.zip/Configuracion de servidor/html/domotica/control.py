import sys
import RPi.GPIO as GPIO

def toggle_led(pin, state):
    try:
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(pin, GPIO.OUT)
        GPIO.output(pin, state)
        return f"El pin {pin} se ha {'encendido' if state else 'apagado'} correctamente."
    except Exception as e:
        return f"Error al cambiar el estado del pin {pin}: {str(e)}"

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 control.py <pin_number> <state>")
        sys.exit(1)

    try:
        pin_number = int(sys.argv[1])
        state = int(sys.argv[2])
        print(toggle_led(pin_number, state))
    except ValueError:
        print("Error: El número de pin y el estado deben ser enteros.")



